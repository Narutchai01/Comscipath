let charactor = prompt("what is your favorite charactor?");
let color = prompt("what is your favorite color?");

console.log(`${charactor}is your favorite charactor`);
console.log(`${charactor} is ${color}`);
